package com.mms.service;

import java.util.List;

import com.mms.bean.Mobile;
import com.mms.bean.PurchaseDetails;
import com.mms.exception.MobileException;

public interface IMobileService 


{
	
	public int addPurchaseDetails(PurchaseDetails pdetails)throws MobileException;
	
	public List<Mobile> getMobiles() throws MobileException;

}
