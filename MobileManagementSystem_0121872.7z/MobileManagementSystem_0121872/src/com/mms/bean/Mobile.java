package com.mms.bean;

public class Mobile

{
	private int mobileid;
	private String Name;
	private double price;
	private int quantity;
	
	
	
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	
	public Mobile(int mobileid, String name, double price, int quantity) {
		super();
		this.mobileid = mobileid;
		Name = name;
		this.price = price;
		this.quantity = quantity;
	}
	
	
	
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + mobileid;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Mobile other = (Mobile) obj;
		if (mobileid != other.mobileid)
			return false;
		return true;
	}
	
	
	
	
	
}
