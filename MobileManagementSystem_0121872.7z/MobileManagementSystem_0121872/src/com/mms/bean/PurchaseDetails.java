package com.mms.bean;

import java.sql.Date;

public class PurchaseDetails 
{

	private int purchaseid;
	private String cname;
	private String mailid;
	private String phoneno;
	private Date purchaseDate;
	private int mobileid;
	public int getPurchaseid() {
		return purchaseid;
	}
	public void setPurchaseid(int purchaseid) {
		this.purchaseid = purchaseid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public Date getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(Date d1) {
		this.purchaseDate = d1;
	}
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	@Override
	public String toString() {
		return "PurchaseDetails [purchaseid=" + purchaseid + ", cname=" + cname
				+ ", mailid=" + mailid + ", phoneno=" + phoneno
				+ ", purchaseDate=" + purchaseDate + ", mobileid=" + mobileid
				+ "]";
	}
	public PurchaseDetails(int purchaseid, String cname, String mailid,
			String phoneno, Date purchaseDate, int mobileid) {
		super();
		this.purchaseid = purchaseid;
		this.cname = cname;
		this.mailid = mailid;
		this.phoneno = phoneno;
		this.purchaseDate = purchaseDate;
		this.mobileid = mobileid;
	}
	public PurchaseDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + purchaseid;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PurchaseDetails other = (PurchaseDetails) obj;
		if (purchaseid != other.purchaseid)
			return false;
		return true;
	}
	
	
	
}
