package com.mms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.mms.bean.Mobile;
import com.mms.bean.PurchaseDetails;
import com.mms.exception.MobileException;
import com.mms.util.DBUtil;

public class MobileDaoImpl implements IMobileDao{

	public Logger myLogger;
	{

	PropertyConfigurator.configure("log4j.properties");
	myLogger = Logger.getLogger(MobileDaoImpl.class.getName());

	}
	
	@Override
	public int addPurchaseDetails(PurchaseDetails pdetails) throws MobileException {
	
		int generatedID = -1;
		
		try(Connection con = DBUtil.getConnection())
		
		{
			
		String cname=pdetails.getCname();
		String mailid=pdetails.getMailid();
		String pno=pdetails.getPhoneno();
		Date purchasedate=(Date) pdetails.getPurchaseDate();
		int mobileid=pdetails.getMobileid();
			
		Statement stm = con.createStatement();	
		ResultSet res = stm.executeQuery("select seq1_purchaseid.NEXTVAL from dual");
		
		if(res.next()==false)
			
		throw new MobileException ("something went wrong while generation the query");
		
		int id = res.getInt(1);
		
		PreparedStatement pstm=
		con.prepareStatement("insert into PurchaseDetails values (?,?,?,?,?,?)");
		
		
		pstm.setInt(1,id);
		pstm.setString(2, cname);
		pstm.setString(3, mailid);
		pstm.setString(4,pno);
		pstm.setDate(5, purchasedate);
		pstm.setInt(6,mobileid);
		
		pstm.execute();
		generatedID =  id;
		
		myLogger.info("details Added Successfully");
		
	}
		catch(SQLException e)
		{
				e.printStackTrace();
				myLogger.error(e.getMessage());
				throw new MobileException(e.getMessage());
		}
	
		catch (Exception e)

		{
			throw new MobileException(e.getMessage());	
		}
		return generatedID;
}


	
	
	
	@Override
	public List<Mobile> getMobiles() throws MobileException {
		

		List <Mobile> mobiles = new ArrayList<Mobile>();
		
		try(Connection con = DBUtil.getConnection())
		{
			Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery("select * from mobiles");
					
			while (res.next())
					{
						Mobile mobile = new Mobile();
						
						mobile.setMobileid(res.getInt("mobileid"));
						mobile.setName(res.getString("name"));
						mobile.setPrice(res.getDouble("price"));
						mobile.setQuantity(res.getInt("quantity"));
						mobiles.add(mobile);
						myLogger.info("ListShown Successfully");
						
					}
		}	
	
	catch (SQLException e)
		{
		e.printStackTrace();
		throw new MobileException (e.getMessage());
		}
	
	catch (Exception e)
	{
		e.printStackTrace();
		throw new MobileException (e.getMessage());
	}

			return mobiles;
		
	}	

}



