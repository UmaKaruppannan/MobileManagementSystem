package com.mms.view;


import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;









import com.mms.bean.Mobile;
import com.mms.bean.PurchaseDetails;
import com.mms.exception.MobileException;
import com.mms.service.IMobileService;
import com.mms.service.MobileServiceImpl;


public class MobileView
{
	
private IMobileService mobileService;

public MobileView()
{
	mobileService = new MobileServiceImpl();
}
public static void main(String[] args)
{
	MobileView emsUI = new MobileView();
	
	
	while(true)
		
	{
	emsUI.showMenu();
	}	
	
	
}

public void showMenu()
{
	Scanner scanner = new Scanner (System.in);
	System.out.println("1) Add");
	System.out.println("2) View");

	System.out.println("Insert your choice");
	int choice = scanner.nextInt();
	
	switch (choice) {
	
	
	case 1:
		add();
	break;
		
		
	case 2:
		View();
		
		break;	
		
	case 3:
		System.out.println("Thank you for exiting");
		System.exit(0);
		break;
		

	default:
		System.out.println("invalid input");
		break;
	}
}




private void View() {

try
{
	List<Mobile> mobiles = mobileService.getMobiles();
	
	Iterator <Mobile> it = mobiles.iterator();
	
	System.out.println("ID\tName\tDepartment\tDesignation\tSalary");
	
	while(it.hasNext())
	{
		Mobile mobile = it.next();
		
		System.out.println(mobile.getMobileid()+ "\t"
				+mobile.getName()+"\t"
				+mobile.getPrice()+"\t"
				+mobile.getQuantity());
		
	}
}	

 catch (MobileException e)
	{
	
	 e.printStackTrace();		

	}
catch (Exception e)
	{
	
	e.printStackTrace();		

	}
}




private void add()
{
	

Scanner scanner = new Scanner(System.in);

System.out.println("Provide PurchaseDetails information");

System.out.println("Customer Name:");
String cname = scanner.next();

System.out.println("Customer maild");
String mailid = scanner.next();

System.out.println("Customer Phoneno");
String phoneno = scanner.next();

System.out.println("Customer PurchaseDate");
String purchasedate = scanner.next();
SimpleDateFormat dt=new SimpleDateFormat("dd/MM/yyyy");

java.util.Date parsed;
java.sql.Date d1=null;
try {
	parsed = dt.parse(purchasedate);
	d1 = new java.sql.Date(parsed.getTime());
} catch (ParseException e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}



System.out.println("Customer mobileid");
int mobileid = scanner.nextInt();



PurchaseDetails pdetails = new PurchaseDetails();

 pdetails.setCname(cname);
 pdetails.setMailid(mailid);
 pdetails.setPhoneno(phoneno);
 pdetails.setPurchaseDate(d1);
 pdetails.setMobileid(mobileid);
 pdetails.setMobileid(mobileid);
 
 
 
 try {
	 
	 int id = mobileService.addPurchaseDetails(pdetails);
	 
	 System.out.println("Details added successfully with id" +id);
 }
	

catch (MobileException e)
 {
	
e.printStackTrace();		

 }
 catch (Exception e)
 {
	
e.printStackTrace();		

 }
}
}
